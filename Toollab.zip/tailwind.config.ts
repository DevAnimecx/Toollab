import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "sans-serif"],
        heading: ["var(--font-heading)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
          text: "#4DA8DA",
          file: "#48E6B0",
          coding: "#FFB84D",
          everyday: "#FF7F7F",
          security: "#C77DFF",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        saffron: '#FF9933',
        'india-green': '#138808',
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      boxShadow: {
        'glow': '0 0 12px var(--accent-color, hsl(var(--primary)))',
      },
      keyframes: {
        "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
        "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        "fade-in-scale": {
          "0%": { opacity: "0", transform: "scale(0.95)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        "slide-in-underline": {
          "0%": { transform: "scaleX(0)" },
          "100%": { transform: "scaleX(1)" },
        },
        "fade-out-slow": {
          "0%": { opacity: "1" },
          "90%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
        "subtle-pulse": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.8", transform: "scale(1.05)" },
        },
        "staggered-fade-slide-up": {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "slide-down": {
          "0%": { opacity: "0", transform: "translateY(-100%)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "gold-shine": {
          "0%, 100%": { "text-shadow": "0 0 4px #fde047, 0 0 10px #fde047, 0 0 20px #facc15" },
          "50%": { "text-shadow": "0 0 8px #fde047, 0 0 15px #fde047, 0 0 30px #facc15" },
        },
        "hot-flame": {
          "0%, 100%": { transform: "scale(1) rotate(-2deg)", color: "hsl(16 100% 50%)" },
          "50%": { transform: "scale(1.1) rotate(2deg)", color: "hsl(35 100% 55%)" },
        },
        "new-glow": {
          "0%, 100%": { "box-shadow": "0 0 5px 1px hsl(var(--primary) / 0.7)" },
          "50%": { "box-shadow": "0 0 10px 2px hsl(var(--primary) / 0.9)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.5s ease-out forwards",
        "fade-in-scale": "fade-in-scale 1s ease-out forwards",
        "slide-in-underline": "slide-in-underline 0.8s 0.5s ease-out forwards",
        "fade-out-slow": "fade-out-slow 2s ease-out forwards",
        "subtle-pulse": "subtle-pulse 10s infinite ease-in-out",
        "staggered-fade-slide-up": "staggered-fade-slide-up 0.5s ease-out forwards",
        "slide-down": "slide-down 0.5s 1.5s ease-out forwards",
        "gold-shine": "gold-shine 2s infinite ease-in-out",
        "hot-flame": "hot-flame 1.5s infinite ease-in-out",
        "new-glow": "new-glow 2s infinite ease-in-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config;